from datetime import datetime
from enum import Enum, IntEnum

class Action(IntEnum):
    Breakfast = 1
    Lunch = 2
    Dinner = 3
    Sleep = 4
    Gym = 5
    Class = 6
    Church = 7
    Television = 8
    River = 9

class Weekday(IntEnum):
    Monday = 1
    Tuesday = 2
    Wednesday = 3
    Thursday = 4
    Friday = 5
    Saturday = 6
    Sunday = 7
    
class Agent: #agent class

  def _init_(self,currentday):
      self.state = currentday
      pass
  def sense_day(self,dt,sick):
      return self.state
  

  def perform_weekday(self):
      
       if self.state == Weekday.Monday:
           return "Monday"
      
       elif self.state == Weekday.Tuesday:
           return "Tuesday"
       
       elif self.state == Weekday.Wednesday:
           return "Wednesday"
       elif self.state == Weekday.Thursday:
           return "Thursday"
       elif self.state == Weekday.Friday:
           return "Friday"
       elif self.state == Weekday.Saturday:
           return "Saturday"
       elif self.state == Weekday.Sunday:
           return "Sunday"


  def __init__(self, initialstate):
       self.state = initialstate
       pass

  def sense_world(self, dt, sick):
    
        return self.state
  
  def perform_action(self):
      
        if self.state == Action.Breakfast:
            return "I am having breakfast"
        
        elif self.state == Action.Lunch:
            return "I am having lunch"
        
        elif self.state == Action.Dinner:
            return "I am having Dinner"
        
        elif self.state == Action.Sleep:
            return "I am Sleeping"
        
        elif self.state == Action.Gym:
            return "I am at the Gym"
        
        elif self.state == Action.Class:
            return "I am at the Class"
        
        elif self.state == Action.Church:
            return "I am at the Church"
        
        elif self.state == Action.Television:
            return "I am watching Television"
        
        elif self.state == Action.River:
            return "I am at the River"
        
