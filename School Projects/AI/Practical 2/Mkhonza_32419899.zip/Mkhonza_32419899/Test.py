from Agent import Action,Weekday , Agent
from datetime import datetime
from enum import Enum, IntEnum

action=int(input("Enter your weekday: "))
action2 = int(input("Enter your hour: "))
d1 = datetime(year = 2020, month = 2, day = 25, hour = 15, minute = 55, second = 59)
testAgent1 = Agent(Action.Breakfast)
testAgent2 = Agent(Action.Lunch)
testAgent3 = Agent(Action.Dinner)
testAgent4 = Agent(Action.Sleep)
testAgent5 = Agent(Action.Gym)
testAgent6 = Agent(Action.Class)
testAgent7 = Agent(Action.Church)
testAgent8 = Agent(Action.Television)
testAgent9 = Agent(Action.River)

testAgent10 = Agent(Weekday.Monday)
testAgent11 = Agent(Weekday.Tuesday)
testAgent12 = Agent(Weekday.Wednesday)
testAgent13 = Agent(Weekday.Thursday)
testAgent14 = Agent(Weekday.Friday)
testAgent15 = Agent(Weekday.Saturday)
testAgent16 = Agent(Weekday.Sunday)


if action==1:
    print(testAgent10.sense_day(d1, False))
    print("My daily schedule is : " + str(d1))
    print(testAgent10.perform_weekday())
    
    if action2==0 or 1 or 2 or 3 or 4 or 5 or 22 or 23:
        print(testAgent4.sense_world(d1, False))
        print(testAgent4.perform_action())
    elif action2==6:
        print(testAgent1.sense_world(d1, False))
        print(testAgent1.perform_action())
    elif action2==7:
        print(testAgent5.sense_world(d1, False))
        print(testAgent5.perform_action())
    elif action2==8 or 9 or 10 or 11 or 12 or 14 or 15 or 16:
        print(testAgent6.sense_world(d1, False))
        print(testAgent6.perform_action())
    elif action2==13:
        print(testAgent2.sense_world(d1, False))
        print(testAgent2.perform_action())
    elif action2==17 or 18 or 20 or 21:
        print(testAgent8.sense_world(d1, False))
        print(testAgent8.perform_action())
    elif action2==19:
        print(testAgent3.sense_world(d1, False))
        print(testAgent3.perform_action())
        
        
elif action==2:
    print(testAgent11.sense_day(d1, False))
    print("My daily schedule is : " + str(d1))
    print(testAgent11.perform_weekday())
    
    if action2==0 or 1 or 2 or 3 or 4 or 5 or 22 or 23:
        print(testAgent4.sense_world(d1, False))
        print(testAgent4.perform_action())
    elif action2==6:
        print(testAgent1.sense_world(d1, False))
        print(testAgent1.perform_action())
    elif action2==7 or 8 or 9 or 10 or 11 or 12 or 14 or 15 or 16:
        print(testAgent6.sense_world(d1, False))
        print(testAgent6.perform_action())
    elif action2==13:
        print(testAgent2.sense_world(d1, False))
        print(testAgent2.perform_action())
    elif action2==17 or 18 or 20 or 21:
        print(testAgent8.sense_world(d1, False))
        print(testAgent8.perform_action())
    elif action2==19:
        print(testAgent3.sense_world(d1, False))
        print(testAgent3.perform_action())
        
        
elif action==3:
    print(testAgent12.sense_day(d1, False))
    print("My daily schedule is : " + str(d1))
    print(testAgent12.perform_weekday())
    
    if action2==0 or 1 or 2 or 3 or 4 or 5 or 22 or 23:
        print(testAgent4.sense_world(d1, False))
        print(testAgent4.perform_action())
    elif action2==6:
        print(testAgent1.sense_world(d1, False))
        print(testAgent1.perform_action())
    elif action2==7:
        print(testAgent5.sense_world(d1, False))
        print(testAgent5.perform_action())
    elif action2==8 or 9 or 10 or 11 or 12 or 14 or 15 or 16:
        print(testAgent6.sense_world(d1, False))
        print(testAgent6.perform_action())
    elif action2==13:
        print(testAgent2.sense_world(d1, False))
        print(testAgent2.perform_action())
    elif action2==17 or 18 or 20 or 21:
        print(testAgent8.sense_world(d1, False))
        print(testAgent8.perform_action())
    elif action2==19:
        print(testAgent3.sense_world(d1, False))
        print(testAgent3.perform_action())
        
        
elif action==4:
    print(testAgent13.sense_day(d1, False))
    print("My daily schedule is : " + str(d1))
    print(testAgent13.perform_weekday())
    
    if action2==0 or 1 or 2 or 3 or 4 or 5 or 22 or 23:
        print(testAgent4.sense_world(d1, False))
        print(testAgent4.perform_action())
    elif action2==6:
        print(testAgent1.sense_world(d1, False))
        print(testAgent1.perform_action())
    elif action2==7 or 8 or 9 or 10 or 11 or 12 or 14 or 15 or 16:
        print(testAgent6.sense_world(d1, False))
        print(testAgent6.perform_action())
    elif action2==13:
        print(testAgent2.sense_world(d1, False))
        print(testAgent2.perform_action())
    elif action2==17 or 18 or 20 or 21:
        print(testAgent8.sense_world(d1, False))
        print(testAgent8.perform_action())
    elif action2==19:
        print(testAgent3.sense_world(d1, False))
        print(testAgent3.perform_action())
        
        
elif action==5:
    print(testAgent14.sense_day(d1, False))
    print("My daily schedule is : " + str(d1))
    print(testAgent14.perform_weekday())
    
    if action2==0 or 1 or 2 or 3 or 4 or 5 or 22 or 23:
        print(testAgent4.sense_world(d1, False))
        print(testAgent4.perform_action())
    elif action2==6:
        print(testAgent1.sense_world(d1, False))
        print(testAgent1.perform_action())
    elif action2==7:
        print(testAgent5.sense_world(d1, False))
        print(testAgent5.perform_action())
    elif action2==8 or 9 or 10 or 11 or 12 or 14 or 15 or 16:
        print(testAgent6.sense_world(d1, False))
        print(testAgent6.perform_action())
    elif action2==13:
        print(testAgent2.sense_world(d1, False))
        print(testAgent2.perform_action())
    elif action2==17 or 18 or 20 or 21:
        print(testAgent8.sense_world(d1, False))
        print(testAgent8.perform_action())
    elif action2==19:
        print(testAgent3.sense_world(d1, False))
        print(testAgent3.perform_action())
        
        
elif action==6:
    print(testAgent15.sense_day(d1, False))
    print("My daily schedule is : " + str(d1))
    print(testAgent15.perform_weekday())
    
    if action2==0 or 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 22 or 23:
        print(testAgent4.sense_world(d1, False))
        print(testAgent4.perform_action())
    elif action2==9:
        print(testAgent1.sense_world(d1, False))
        print(testAgent1.perform_action())
    elif action2==10 or 11 or 12 or 13 or 15 or 16 or 17 or 18:
        print(testAgent9.sense_world(d1, False))
        print(testAgent9.perform_action())
    elif action2==14:
        print(testAgent2.sense_world(d1, False))
        print(testAgent2.perform_action())
    elif action2==20 or 21:
        print(testAgent8.sense_world(d1, False))
        print(testAgent8.perform_action())
    elif action2==19:
        print(testAgent3.sense_world(d1, False))
        print(testAgent3.perform_action())
        
        
elif action==7:
    print(testAgent16.sense_day(d1, False))
    print("My daily schedule is : " + str(d1))
    print(testAgent16.perform_weekday())
    
    if action2==0 or 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8 or 22 or 23:
        print(testAgent4.sense_world(d1, False))
        print(testAgent4.perform_action())
    elif action2==9:
        print(testAgent1.sense_world(d1, False))
        print(testAgent1.perform_action())
    elif action2==11 or 12 or 13 or 15 or 16 or 17 or 18:
        print(testAgent9.sense_world(d1, False))
        print(testAgent9.perform_action())
    elif action2==10:
        print(testAgent7.sense_world(d1, False))
        print(testAgent7.perform_action())
    elif action2==14:
        print(testAgent2.sense_world(d1, False))
        print(testAgent2.perform_action())
    elif action2==20 or 21:
        print(testAgent8.sense_world(d1, False))
        print(testAgent8.perform_action())
    elif action2==19:
        print(testAgent3.sense_world(d1, False))
        print(testAgent3.perform_action())