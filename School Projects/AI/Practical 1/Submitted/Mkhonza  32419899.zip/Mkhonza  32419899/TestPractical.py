from Agent import Action, Agent
from datetime import datetime
from enum import Enum, IntEnum

action=int(input("Enter your action: "))
d1 = datetime(year = 2020, month = 2, day = 25, hour = 15, minute = 55, second = 59)
testAgent1 = Agent(Action.Breakfast)
testAgent2 = Agent(Action.Lunch)
testAgent3 = Agent(Action.Dinner)
testAgent4 = Agent(Action.Sleep)
testAgent5 = Agent(Action.Gym)
testAgent6 = Agent(Action.Class)
testAgent7 = Agent(Action.Church)
testAgent8 = Agent(Action.Television)
testAgent9 = Agent(Action.River)

if action==1:
    print(testAgent1.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent1.perform_action())

elif action==2:
    print(testAgent2.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent2.perform_action())

elif action==3:
    print(testAgent3.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent3.perform_action())

elif action==4:
    print(testAgent4.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent4.perform_action())

elif action==5:
    print(testAgent5.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent5.perform_action())
    
elif action==6:
    print(testAgent6.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent6.perform_action())

elif action==7:
    print(testAgent7.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent7.perform_action())

elif action==8:
    print(testAgent8.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent8.perform_action())

elif action==9:
    print(testAgent9.sense_world(d1, False))
    print("My daily schedule : " + str(d1))
    print(testAgent9.perform_action())
else:
    print("Invalid input")

