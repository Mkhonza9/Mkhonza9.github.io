import wolframalpha
import pandas as pd
import matplotlib.pyplot as plt
  

question = input('Enter your favorite actors movies:: ')

app_id = 'AYEU9E-TKL7694PW8'

client = wolframalpha.Client(app_id)

res = client.query(question)

answer = next(res.results).text
  
print(answer)