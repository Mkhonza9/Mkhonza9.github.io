import numpy as np
import matplotlib.pyplot as plt
import imdb

 
ia = imdb.IMDb()
 
app_id = 'AYEU9E-TKL7694PW8'
 
# creating the dataset
data = {'3 Idiots':8.4, 'law abiding citizen':7.4, 'Being Frank':6.1,
        }
courses = list(data.keys())
values = list(data.values())
  
fig = plt.figure(figsize = (10, 5))
 
# creating the bar plot
plt.bar(courses, values, color ='green',
        width = 0.4)
 
plt.xlabel("Movies name")
plt.ylabel("The ratings")
plt.title("Top 3 movie ratings")
plt.show()

top = ia.get_top250_movies()
print("Top 3 movie ratings: ")
for movie in top[0:3]:
  print(movie)
print()
